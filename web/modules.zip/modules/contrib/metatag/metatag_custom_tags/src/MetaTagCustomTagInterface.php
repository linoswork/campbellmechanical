<?php

namespace Drupal\metatag_custom_tags;

use Drupal\Core\Config\Entity\ConfigEntityInterface;

/**
 * Provides an interface for defining Custom Tag entities.
 */
interface MetaTagCustomTagInterface extends ConfigEntityInterface {
  // Add get/set methods for your configuration properties here.
}
